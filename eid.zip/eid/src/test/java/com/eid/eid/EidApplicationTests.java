package com.eid.eid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EidApplicationTests {

	@Test
	void contextLoads() {
	}

}
