package com.eid.eid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EidApplication {

	public static void main(String[] args) {
		SpringApplication.run(EidApplication.class, args);
	}

}
